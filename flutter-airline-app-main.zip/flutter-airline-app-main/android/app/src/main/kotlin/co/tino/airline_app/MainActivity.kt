package co.tino.airline_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
