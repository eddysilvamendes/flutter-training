
// ignore_for_file: constant_identifier_names

const String BASE_URL = '';

String lastName = 'Firstname';
String firstName = 'Lastname';
String email = 'Email';
String birthdate = 'Birthdate';
String phone = 'Phone';
String promoCode = 'Promo Code';
String pwd = 'Password';
String confirmPwd = 'Confirm Password';

const String LASTNAME = 'LASTNAME';
const String FIRSTNAME = 'FIRSTNAME';
const String EMAIL = 'EMAIL';
const String ACCOUNTID = 'ACCOUNT_ID';
const String USERNAME = 'USERNAME';
const String PHONE = 'PHONE';
const String BIRTHDATE = 'BIRTHDATE';
const String TOKEN = 'TOKEN';
const String REFRESHTOKEN = 'REFRESH_TOKEN';
const String APPNAME = 'STARTER TEMPLATE';

const String ERROR_STRING = 'An error occured, try again';
const String SENT_ERROR = 'Unable to send the request';
const String DISCONNECT_STRING = 'Do you want to disconnect ?';
const String LOGIN_STRING = 'Login success';
const String REGISTRATION_STRING = 'Registration success';
const String ONGOING_OPERATION_STRING = 'A password reset operation is already in progress';
